// src/types/options.ts (NEW FILE)
// A generic type for our dropdown options.
export interface Option {
  value: string;
  label: string;
}
